<?php

/*
require __DIR__ . '/autoload.php';

$news = \App\Models\News::findAll();
var_dump( $news[3]->author );
*/

function first()
{
    echo 'First';
    return false;
}

function second()
{
    echo 'Second';
    return true;
}

var_dump( second() xor first() );