<?php

namespace App\Models;

interface HasEmail
{

    public function getEmail();

}