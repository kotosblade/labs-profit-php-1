<?php

require __DIR__ . '/autoload.php';
$controller = new \App\Controllers\News();
$controller->action('One');